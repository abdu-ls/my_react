import React, { useState } from 'react';

import { ScrollView, Text, StyleSheet, TextInput, Pressable } from 'react-native';



export default function Feedback({navigation}) {
  const [firstName, onChangeFirstName] = useState('');
  const [message, onChangemessage] = useState('');
  const [phone, onChangephone] = useState('');
  return (
    <ScrollView style={styles.container} keyboardDismissMode="on-drag">
      <Text style={styles.headerText}>Welcome to Little Lemon</Text>
      <Text style={styles.regularText}>
        Please leave us some feedback on your visit experience
        to serve you better
      </Text>
      <TextInput
        style={styles.inputBox}
        value={firstName}
        onChangeText={onChangeFirstName}
        placeholder={'First Name'}
      />
      <TextInput
        style={styles.inputBox}
        value={phone}
        onChangeText={onChangephone}
        placeholder={'contact number'}
       keyboardType={'phone-pad'}
      />
       <TextInput
        style={styles.messageInput}
        value={message}
        onChangeText={onChangemessage}
        placeholder={'Pls Leave a feedback'}
        multiline={true}
      />
      <Pressable onPress={() => navigation.navigate('Welcome')}> 
        <Text style={styles.buttonText}>Submit</Text> 
      </Pressable> 
    </ScrollView>
  );
}

 

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerText: {
    padding: 40,
    fontSize: 30,
    color: '#EDEFEE',
    textAlign: 'center',
  },
  regularText: {
    fontSize: 24,
    padding: 20,
    marginVertical: 8,
    color: '#EDEFEE',
    textAlign: 'center',
  },
  inputBox: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    fontSize: 16,
    textAlign: 'center',
    borderColor: 'EDEFEE',
    backgroundColor: '#EDEFEE',
  },
  messageInput: { 
    height: 100, 
    margin: 12, 
    borderWidth: 1, 
    padding: 10, 
    fontSize: 16, 
    backgroundColor: '#EDEFEE', 
  },
});